# The Armory

Responsive HTML/CSS/JavaScript recreation of the supplied dashboard reference. Open `dist/index.html` in a browser or serve `dist` with a static HTTP server. No build or dependencies required.

The default desktop composition follows the 1024 × 1536 reference. Navigation, collection tabs, search, sample record details, local notes, settings, wishlist, and JSON backup are interactive. All records and summary values are illustrative. Notes and preferences use this browser's localStorage; no backend or cloud synchronization is configured.

## Assets

- `dist/assets/reference.png`: the user-supplied reference; used as a CSS photographic crop for the lower scene and thumbnail.
- `dist/assets/hero.png`: clean mountain background created with the built-in ImageGen tool.

ImageGen prompt: Edit the supplied dashboard screenshot to recover only the top hero photographic background, removing all interface elements and text while preserving the mountain silhouette, dusk sky, warm sunset, framing trees, misty valley, winding river, blue-gray grading, and dark bottom fade. Output a landscape background plate, excluding the lower dashboard.

Validation: JavaScript syntax, local HTTP responses, asset existence, and SVG references. Browser visual QA was unavailable in the execution environment.
